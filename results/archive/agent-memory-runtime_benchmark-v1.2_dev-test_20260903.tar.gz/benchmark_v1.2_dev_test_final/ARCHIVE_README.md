# Benchmark v1.2 Development + Test evidence archive

Created: 2026-09-03  
Scope: Frozen Benchmark v1.2 Development and the single authorized Test run  
Holdout: Not executed and intentionally excluded

This archive preserves the reviewed benchmark lineage, frozen scoring and
experiment protocols, final/acceptance reports, and all machine-readable files
from the two completed formal runs.

The Test evidence was produced from Git commit
`9080b03ef4bee36555bccc6ddda1e79235a4556f`. Test acceptance was recorded in
commit `dfdc638`. The Development manifest records the earlier base commit
`c03023a`; see the final report for the documented provenance limitation.

Verify the unpacked contents from the archive root with:

```bash
sha256sum --check SHA256SUMS
```

The checksum list covers every evidence file below `benchmark/`, `docs/`, and
`results/`. It does not list itself or this README. The outer archive checksum
is stored beside the `.tar.gz` file and in the repository's archive record.

No API key or credential is included. Both run manifests set
`secrets_recorded` to `false`, and the archived results passed a token-pattern
scan before packaging.
